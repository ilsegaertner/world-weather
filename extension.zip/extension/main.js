console.log("The extension is up and running");

